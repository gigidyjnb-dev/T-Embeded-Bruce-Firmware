#ifndef WIFI_DEAUTHER_H
#define WIFI_DEAUTHER_H

#include "scan_hosts.h"

void stationDeauth(Host host);

#endif
