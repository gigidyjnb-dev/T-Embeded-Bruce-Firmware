#include "core/display.h"

void parse_BSSID(char *bssid_without_colon, const char *bssid);

void net_ap(int i);

void claro_ap(int i);

void dpwo_setup();
